package com.example.githuboauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GithubOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(GithubOauthApplication.class, args);
	}

}
