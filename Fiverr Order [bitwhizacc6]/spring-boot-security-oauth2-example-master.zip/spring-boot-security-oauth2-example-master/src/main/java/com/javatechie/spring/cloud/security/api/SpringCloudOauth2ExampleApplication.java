package com.javatechie.spring.cloud.security.api;

import java.security.Principal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@EnableOAuth2Sso		//Enabling OAuth2
@RestController
public class SpringCloudOauth2ExampleApplication {
	
	@GetMapping("/")
	public String message(Principal principal) {
		return "Hello "+principal.getName();
	}

	@GetMapping("/login/oauth2/code/github")
	public String redirect(){
		return "You are in!";
	}

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudOauth2ExampleApplication.class, args);
	}

}
